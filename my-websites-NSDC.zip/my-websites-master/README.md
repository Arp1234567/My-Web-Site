# my-websites
My first html-css website

## html, css:

#### [My first site](https://c-coretex.github.io/my-websites/html&css-training/)

---


## html, scss, js

#### [My second site](https://c-coretex.github.io/my-websites/room-homepage-master/)

---


## react, scss, RESTful API:

#### [My third site](https://c-coretex.github.io/my-websites/rest-countries/)

---

